export const OPEN_WEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5";
export const OPEN_WEATHER_API_KEY = import.meta.env.VITE_OPEN_WEATHER_API_KEY;
