import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import { motion } from "framer-motion";
import { useTheme } from "@mui/material/styles";
import { useAuth } from "./AuthProvider";
import LanguageToggle from "@components/inputs/LanguageToggle";
import ThemeToggle from "@components/theme/ThemeToggle";
import loginLight from "../../assets/login-image-light.png";
import loginDark from "../../assets/login-image-dark.png";

const LoginPage: React.FC = () => {
  const { t } = useTranslation("auth");
  const { login } = useAuth();
  const navigate = useNavigate();
  const theme = useTheme();

  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError(t("enterName"));
      return;
    }
    login(name.trim());
    navigate("/");
  };

  return (
    <Box
      component={motion.div}
      animate={{
        background: [
          theme.palette.mode === "light"
            ? "linear-gradient(135deg, #fdfefe, #f5fbff, #eaf6ff)"
            : "linear-gradient(135deg, #0d1117, #161b22, #1e242c)",
          theme.palette.mode === "light"
            ? "linear-gradient(135deg, #f5fbff, #eaf6ff, #fdfefe)"
            : "linear-gradient(135deg, #161b22, #1e242c, #0d1117)",
        ],
      }}
      transition={{ duration: 12, repeat: Infinity, repeatType: "reverse" }}
      sx={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        p: 3,
      }}
    >
      <Paper
        elevation={3}
        component={motion.div}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "space-between",
          width: "100%",
          maxWidth: 900,
          borderRadius: 0.75,
          backgroundColor: theme.palette.background.paper,
          boxShadow: theme.shadows[6],
          overflow: "hidden",
        }}
      >
        <Box sx={{ flex: 1, textAlign: "center", p: 4 }}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <Typography
              variant="h4"
              gutterBottom
              sx={{
                fontWeight: 700,
                color: theme.palette.text.primary,
                mb: 3,
              }}
            >
              {t("login")}
            </Typography>
          </motion.div>

          <form onSubmit={handleSubmit} noValidate>
            <Stack spacing={3}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.6,
                  delay: 0.2,
                  ease: [0.22, 1, 0.36, 1],
                }}
              >
                <TextField
                  label={t("enterName")}
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setError("");
                  }}
                  error={!!error}
                  helperText={error}
                  fullWidth
                  variant="outlined"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      borderRadius: 0.5,
                      backgroundColor: theme.palette.background.default,
                      input: { color: theme.palette.text.primary },
                      "& fieldset": { borderColor: theme.palette.divider },
                      "&:hover fieldset": {
                        borderColor: theme.palette.primary.light,
                        transition: "border-color 0.3s ease",
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: theme.palette.primary.main,
                      },
                    },
                    "& .MuiInputLabel-root": {
                      color: theme.palette.text.secondary,
                    },
                    "& .MuiFormHelperText-root": {
                      color: theme.palette.error.main,
                    },
                  }}
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.6,
                  delay: 0.4,
                  ease: [0.22, 1, 0.36, 1],
                }}
              >
                <Button
                  type="submit"
                  variant="contained"
                  size="large"
                  fullWidth
                  component={motion.button}
                  whileHover={{
                    scale: 1.02,
                  }}
                  whileTap={{ scale: 0.98 }}
                  sx={{
                    borderRadius: 0.5,
                    py: 1.5,
                    fontWeight: 600,
                    fontSize: "1rem",
                    background: `linear-gradient(90deg, ${theme.palette.primary.light}, ${theme.palette.primary.main})`,
                    textTransform: "none",
                  }}
                >
                  {t("login")}
                </Button>
              </motion.div>
            </Stack>
          </form>
        </Box>

        <Box
          component={motion.img}
          src={theme.palette.mode === "light" ? loginLight : loginDark}
          alt="Weather illustration"
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          sx={{
            flex: 1,
            maxWidth: 400,
            width: "100%",
            borderTopRightRadius: 8,
            borderBottomRightRadius: 8,
            borderTopLeftRadius: 0,
            borderBottomLeftRadius: 0,
            mt: { xs: 4, md: 0 },
          }}
        />
      </Paper>

      <Box
        sx={{
          py: 3,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 2,
        }}
      >
        <LanguageToggle variant="dropdown" />
        <ThemeToggle />
      </Box>
    </Box>
  );
};

export default LoginPage;
